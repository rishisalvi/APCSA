
/**
 *	Counts the frequency of letters in a file and produces a histogram.
 *
 *	@author	
 *	@since	
 */
public class LetterCount {
	
	// Fields go here, all must be private
	
	/* Constructor */							
	public LetterCount() {}
	
	/* Main routine */
	public static void main(String[] args) {
		LetterCount lc = new LetterCount();
		if (args.length != 1)
			System.out.println("Usage: java LetterCount <inputFile>");
		else
			lc.run(args);
	}
	
	/**	The core program of the class, it
	 *	- opens the input file
	 *	- reads the file and counts the letters
	 *	- closes the input file
	 *	- prints the histogram of the letter count
	 */
	public void run(String[] args) {
		String fileName = args[0];
	}
	
}